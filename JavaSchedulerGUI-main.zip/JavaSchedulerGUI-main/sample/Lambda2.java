package sample;

import javafx.scene.control.Control;

public interface Lambda2 {
    public void enableElement(Control fxmlElement);
}
