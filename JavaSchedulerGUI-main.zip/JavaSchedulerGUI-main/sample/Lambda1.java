package sample;

import javafx.collections.ObservableList;
import models.Country;

public interface Lambda1 {
    public void findOne(int countryId, ObservableList<Country> country);
}
